
# @brief
#	This file processed the main flow.


# create a file <loop_dev> to record loop device
export INFO_FILE = .info

export MOUNT_DIR_INFO_HEAD = mount_dir
export LOOP_DEV_INFO_HEAD = loop_dev
export IMAGE_INFO_HEAD = image
export FLAG_INFO_HEAD = flag

# block size
export BLK_SZ = 4096

# mount dir
export MOUNT_DIR = mount

all: $(MOUNT_DIR) $(IMAGE) _mount
	@echo === successfully ===

$(MOUNT_DIR):
	mkdir -p $@
ifeq ($(wildcard $(INFO_FILE)),)
	touch .info
endif
	make -f update_info.mk MOUNT_DIR_INFO=$(shell pwd)/$(notdir $@)

$(IMAGE):
	make -f image.mk

_mount:
	make -f mount.mk

umount:
	make -f umount.mk
	
clean:
	make -f clean.mk
