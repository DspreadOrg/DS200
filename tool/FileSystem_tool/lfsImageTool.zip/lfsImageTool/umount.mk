
# @brief
#	This file is used to unmount loop device from the target directory.


# check mount state
MOUNT_STA = $(shell df | grep 'lfs')
ifeq ($(MOUNT_STA),)
$(error image is not been mounted !!!)
endif
ifeq ($(word 1,$(MOUNT_STA)), lfs)
ifneq ($(word 6,$(MOUNT_STA)), $(shell pwd)/$(MOUNT_DIR))
$(error image is not been mounted !!!)
endif
else
$(error image is not been mounted !!!)
endif

# if loop_dev info exsit, read it out
LOOP_DEV_LINE = $(shell sed -n '/\[$(LOOP_DEV_INFO_HEAD)\]/p' $(INFO_FILE))
ifneq ($(LOOP_DEV_LINE),)
LOOP_DEV = $(word 2,$(LOOP_DEV_LINE))
endif

ifeq ($(LOOP_DEV),)
ifeq ($(LOOP),)
$(error no loop device found !!!)
endif
LOOP_DEV = /dev/$(LOOP)
endif

all:
	@echo umounting ...
	@echo loop device: $(LOOP_DEV)
	sudo umount $(MOUNT_DIR)
	sudo losetup -d $(LOOP_DEV)
	make -f update_info.mk FLAG_INFO=0
	@echo === successfully ===
