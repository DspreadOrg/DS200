
# @brief
#	This file is used to mount loop device to the target directory.
#	When it comes to this file, the image has been already created.

# check mount state
MOUNT_STA = $(shell df | grep 'lfs')
ifeq ($(word 1,$(MOUNT_STA)), lfs)
ifeq ($(word 6,$(MOUNT_STA)), $(shell pwd)/$(MOUNT_DIR))
$(error image has been already mounted !!!)
endif
endif

# if loop_dev info exsit, read it out
LOOP_DEV_LINE = $(shell sed -n '/\[$(LOOP_DEV_INFO_HEAD)\]/p' $(INFO_FILE))
ifneq ($(LOOP_DEV_LINE),)
LOOP_DEV = $(word 2,$(LOOP_DEV_LINE))
endif

FLAG_LINE = $(shell sed -n '/\[$(FLAG_INFO_HEAD)\]/p' $(INFO_FILE))
ifneq ($(FLAG_LINE),)
REMOUNT_FLAG = 1
else
REMOUNT_FLAG = 0
endif

IMAGE_LINE = $(shell sed -n '/\[$(IMAGE_INFO_HEAD)\]/p' $(INFO_FILE))
ifneq ($(IMAGE_LINE),)
IMAGE_TMP = $(word 2,$(IMAGE_LINE))
endif

ifeq ($(IMAGE_TMP),)
REMOUNT_FLAG = 1
endif

ifeq ($(REMOUNT_FLAG),1)  # if loop_dev file does not exsit (may be deleted by accident), or it's empty
ifeq ($(LOOP),)  # if user does not specify a loop device
LOOP_DEV = $(shell losetup -f)  # then find a free loop device
else
LOOP_DEV = /dev/$(LOOP)  # or use user apecified loop device
endif
ifeq ($(LOOP_DEV),)  # if there is no free loop device
$(error no loop device found !!!)  # report error
endif
ifeq ($(LOOP_DEV),/dev/)  # if user does not specify a loop device
$(error no loop device found !!!)  # report error
endif
endif

all:
	@echo mounting ...
ifeq ($(REMOUNT_FLAG), 1)
	@echo loop device: $(LOOP_DEV)
	make -f update_info.mk LOOP_DEV_INFO=$(LOOP_DEV)
endif
ifeq ($(IMAGE_TMP),)
	make -f update_info.mk IMAGE_INFO=$(IMAGE)
endif
	sudo chmod a+rw $(LOOP_DEV)
	sudo losetup $(LOOP_DEV) $(IMAGE)
ifeq ($(REMOUNT_FLAG), 0)
	./lfs --block_size=$(BLK_SZ) --block_count=$(COUNT) --read_size=$(BLK_SZ) --prog_size=$(BLK_SZ) --lookahead=256 --format $(LOOP_DEV)
endif
	./lfs --block_size=$(BLK_SZ) --block_count=$(COUNT) --read_size=$(BLK_SZ) --prog_size=$(BLK_SZ) --lookahead=256 $(LOOP_DEV) $(MOUNT_DIR)
	make -f update_info.mk FLAG_INFO=1
