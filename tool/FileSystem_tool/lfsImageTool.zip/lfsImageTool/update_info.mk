
MOUNT_DIR_INFO = 
LOOP_DEV_INFO = 
IMAGE_INFO = 
FLAG_INFO =

all:
ifneq ($(MOUNT_DIR_INFO),)
ifneq ($(shell sed -n '/\[$(MOUNT_DIR_INFO_HEAD)\]/p' $(INFO_FILE)),)
	sed -i '/\[$(MOUNT_DIR_INFO_HEAD)\]/d' $(INFO_FILE)
endif
	echo [$(MOUNT_DIR_INFO_HEAD)] $(MOUNT_DIR_INFO) >> $(INFO_FILE)
endif
ifneq ($(LOOP_DEV_INFO),)
ifneq ($(shell sed -n '/\[$(LOOP_DEV_INFO_HEAD)\]/p' $(INFO_FILE)),)
	sed -i '/\[$(LOOP_DEV_INFO_HEAD)\]/d' $(INFO_FILE)
endif
	echo [$(LOOP_DEV_INFO_HEAD)] $(LOOP_DEV_INFO) >> $(INFO_FILE)
endif
ifneq ($(IMAGE_INFO),)
ifneq ($(shell sed -n '/\[$(IMAGE_INFO_HEAD)\]/p' $(INFO_FILE)),)
	sed -i '/\[$(IMAGE_INFO_HEAD)\]/d' $(INFO_FILE)
endif
	echo [$(IMAGE_INFO_HEAD)] $(IMAGE_INFO) >> $(INFO_FILE)
endif
ifneq ($(FLAG_INFO),)
ifneq ($(shell sed -n '/\[$(FLAG_INFO_HEAD)\]/p' $(INFO_FILE)),)
	sed -i '/\[$(FLAG_INFO_HEAD)\]/d' $(INFO_FILE)
endif
	echo [$(FLAG_INFO_HEAD)] $(FLAG_INFO) >> $(INFO_FILE)
endif