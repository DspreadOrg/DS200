
# @brief
#	This file is used to create image.


# loop device to be used
ifeq ($(LOOP),)
LOOP_DEV = $(shell losetup -f)
else
LOOP_DEV = /dev/$(LOOP)
endif
ifeq ($(LOOP_DEV),)
$(error no loop device found !!!)
endif

$(IMAGE):
	@echo making image ...
	@echo loop device: $(LOOP_DEV)
	sudo chmod a+rw $(LOOP_DEV)
	dd if=/dev/zero of=$@ bs=$(BLK_SZ) count=$(COUNT)
	make -f update_info.mk LOOP_DEV_INFO=$(LOOP_DEV) IMAGE_INFO=$(IMAGE)
