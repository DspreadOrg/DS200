
# @brief
#	This file is used to clean target.

ifeq ($(wildcard $(INFO_FILE)), $(INFO_FILE))
MOUNT_DIR_LINE = $(shell sed -n '/\[$(MOUNT_DIR_INFO_HEAD)\]/p' $(INFO_FILE))
ifneq ($(MOUNT_DIR_LINE),)
MOUNT_DIR = $(word 2,$(MOUNT_DIR_LINE))
endif
endif

ifeq ($(wildcard $(INFO_FILE)), $(INFO_FILE))
IMAGE_LINE = $(shell sed -n '/\[$(IMAGE_INFO_HEAD)\]/p' $(INFO_FILE))
ifneq ($(IMAGE_LINE),)
IMAGE = $(word 2,$(IMAGE_LINE))
endif
endif

# check mount state
MOUNT_STA = $(shell df | grep 'lfs')
ifeq ($(word 1,$(MOUNT_STA)), lfs)
ifeq ($(word 6,$(MOUNT_STA)), $(shell pwd)/$(notdir $(MOUNT_DIR)))
$(error image is mounted, please umount firstly !!!)
endif
endif

all:
	@echo cleaning ...
	rm -rf $(MOUNT_DIR) $(IMAGE) $(INFO_FILE)
	@echo clean done !!!